#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>

using namespace std;

const int MAX_BOOKINGS = 100;

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

class Booking {
public:
    int bookingID;
    string customerName;
    string destination;
    string time;
    int price;

    Booking() {
        bookingID = 0;
        customerName = "";
        destination = "";
        time = "";
        price = 0;
    }

    Booking(int id, string name, string dest, string t, int p) {
        bookingID = id;
        customerName = name;
        destination = dest;
        time = t;
        price = p;
    }

    virtual void input() = 0;
    virtual void display() = 0;
    virtual void saveToFile(ofstream &file) = 0;
    virtual bool loadFromFile(ifstream &file) = 0;

    virtual ~Booking() {}
};

class TourBooking : public Booking {
public:
    string packageType;

    TourBooking() : Booking() {
        packageType = "Standard";
    }

    TourBooking(int id) {
        bookingID = id;
        packageType = "Standard";
    }

    void input() override {
        cout << "Enter tourist name: ";
        cin.ignore();
        getline(cin, customerName);

        cout << "Select Package Type:\n1. Standard\n2. Deluxe\n3. Premium\nChoice: ";
        int option;
        cin >> option;

        cout << "Available Tours:\n";
        for (int i = 0; i < 8; i++) {
            cout << i + 1 << ". " << tourNames[i] << " - ";
            if (option == 1) cout << standardPrices[i];
            else if (option == 2) cout << deluxePrices[i];
            else if (option == 3) cout << premiumPrices[i];
            else cout << standardPrices[i];
            cout << " (Departure: " << departureTimes[i] << ")\n";
        }

        int choice;
        cout << "Select tour: ";
        cin >> choice;
        if (choice < 1 || choice > 8) choice = 1;

        destination = tourNames[choice - 1];
        time = departureTimes[choice - 1];

        if (option == 1) {
            packageType = "Standard";
            price = standardPrices[choice - 1];
        } else if (option == 2) {
            packageType = "Deluxe";
            price = deluxePrices[choice - 1];
        } else if (option == 3) {
            packageType = "Premium";
            price = premiumPrices[choice - 1];
        } else {
            packageType = "Standard";
            price = standardPrices[choice - 1];
        }
    }

    void display() override {
        cout << left << setw(10) << bookingID
             << setw(20) << customerName
             << setw(20) << destination
             << setw(15) << packageType
             << setw(10) << price
             << setw(10) << time << endl;
    }

    void saveToFile(ofstream &file) override {
        file << bookingID << "," << customerName << "," << destination << "," << packageType << "," << price << "," << time << "\n";
    }

    bool loadFromFile(ifstream &file) override {
        string line;
        getline(file, line);
        if (line.empty()) return false;

        int pos1 = line.find(',');
        int pos2 = line.find(',', pos1 + 1);
        int pos3 = line.find(',', pos2 + 1);
        int pos4 = line.find(',', pos3 + 1);
        int pos5 = line.find(',', pos4 + 1);

        bookingID = stoi(line.substr(0, pos1));
        customerName = line.substr(pos1 + 1, pos2 - pos1 - 1);
        destination = line.substr(pos2 + 1, pos3 - pos2 - 1);
        packageType = line.substr(pos3 + 1, pos4 - pos3 - 1);
        price = stoi(line.substr(pos4 + 1, pos5 - pos4 - 1));
        time = line.substr(pos5 + 1);

        return true;
    }

private:
    string tourNames[8] = {
        "Switzerland", "New York City", "Dubai Desert Safari", "Mecca Pilgrimage",
        "London City Tour", "Paris Attractions", "Tokyo Excursion", "Sydney Beaches"
    };

    int standardPrices[8] = {18000, 25000, 20000, 28000, 27000, 29000, 31000, 32000};
    int deluxePrices[8] = {22000, 30000, 24000, 33000, 31000, 34000, 35000, 37000};
    int premiumPrices[8] = {26000, 35000, 29000, 37000, 36000, 39000, 40000, 42000};
    string departureTimes[8] = {
        "8:00 AM", "9:30 AM", "11:00 AM", "12:15 PM",
        "2:00 PM", "3:30 PM", "5:00 PM", "6:30 PM"
    };
};

class BookingManager {
public:
    Booking* bookings[MAX_BOOKINGS];
    int totalBookings;
    int nextID;

    BookingManager() {
        totalBookings = 0;
        nextID = 1;
        for (int i = 0; i < MAX_BOOKINGS; i++) bookings[i] = nullptr;
    }

    ~BookingManager() {
        for (int i = 0; i < totalBookings; i++) {
            delete bookings[i];
        }
    }

    void addBooking() {
        if (totalBookings >= MAX_BOOKINGS) {
            cout << "Cannot add more bookings.\n";
            return;
        }

        TourBooking* t = new TourBooking(nextID);
        nextID++;
        t->input();
        bookings[totalBookings] = t;
        totalBookings++;

        cout << "Booking added successfully.\n";
    }

    void showBookings() {
        if (totalBookings == 0) {
            cout << "No bookings to show.\n";
            return;
        }

        cout << left << setw(10) << "ID"
             << setw(20) << "Name"
             << setw(20) << "Destination"
             << setw(15) << "Package"
             << setw(10) << "Price"
             << setw(10) << "Time" << endl;
        cout << string(85, '-') << endl;

        for (int i = 0; i < totalBookings; i++) {
            bookings[i]->display();
        }
    }

    void saveToFile(string filename) {
        ofstream file(filename);
        if (!file) {
            cout << "Could not open file.\n";
            return;
        }

        for (int i = 0; i < totalBookings; i++) {
            bookings[i]->saveToFile(file);
        }

        file.close();
        cout << "Bookings saved to " << filename << endl;
    }

    void loadFromFile(string filename) {
        ifstream file(filename);
        if (!file) {
            cout << "File not found. Starting fresh.\n";
            return;
        }

        for (int i = 0; i < totalBookings; i++) {
            delete bookings[i];
        }

        totalBookings = 0;
        nextID = 1;

        while (!file.eof()) {
            TourBooking* t = new TourBooking();
            if (t->loadFromFile(file)) {
                bookings[totalBookings] = t;
                totalBookings++;
                if (t->bookingID >= nextID) {
                    nextID = t->bookingID + 1;
                }
            } else {
                delete t;
            }
        }

        file.close();
        cout << "Bookings loaded from " << filename << endl;
    }

    void changeBooking() {
        if (totalBookings == 0) {
            cout << "No bookings to change.\n";
            return;
        }

        int id;
        cout << "Enter booking ID to modify: ";
        cin >> id;

        for (int i = 0; i < totalBookings; i++) {
            if (bookings[i]->bookingID == id) {
                cout << "Old data:\n";
                bookings[i]->display();
                cout << "Enter new data:\n";
                bookings[i]->input();
                cout << "Booking updated.\n";
                return;
            }
        }

        cout << "Booking ID not found.\n";
    }

    void removeBooking() {
        if (totalBookings == 0) {
            cout << "No bookings to delete.\n";
            return;
        }

        int id;
        cout << "Enter booking ID to delete: ";
        cin >> id;

        for (int i = 0; i < totalBookings; i++) {
            if (bookings[i]->bookingID == id) {
                delete bookings[i];
                for (int j = i; j < totalBookings - 1; j++) {
                    bookings[j] = bookings[j + 1];
                }
                bookings[totalBookings - 1] = nullptr;
                totalBookings--;
                cout << "Booking deleted.\n";
                return;
            }
        }

        cout << "Booking ID not found.\n";
    }
};

int main() {
    BookingManager manager;
    string file = "tour_bookings.txt";

    manager.loadFromFile(file);

    int option;

    do {
        clearScreen();
        cout << "\n           ======== TOURISM MANAGEMANT SYSTEM ========\n";
        cout << "1. Add Tour Booking\n";
        cout << "2. Display All Bookings\n";
        cout << "3. Modify a Booking\n";
        cout << "4. Delete a Booking\n";
        cout << "5. Save Bookings\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> option;

        clearScreen();

        if (option == 1) {
            manager.addBooking();
        } else if (option == 2) {
            manager.showBookings();
        } else if (option == 3) {
            manager.changeBooking();
        } else if (option == 4) {
            manager.removeBooking();
        } else if (option == 5) {
            manager.saveToFile(file);
        } else if (option == 0) {
            cout << "Exiting...\n";
        } else {
            cout << "Invalid choice.\n";
        }

        if (option != 0) {
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
        }

    } while (option != 0);

    return 0;
}
